Local SQLite database. aetherbound.sqlite is created automatically at the first sign up.
Back up this file to keep the accounts. Never share it: it contains emails and password hashes.
