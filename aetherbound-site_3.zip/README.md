# AetherboundSMP website

PHP 7.4+ site, no database and no build step. Upload the folder contents to your web root (Apache with `.htaccess` support recommended).

## Structure

```
index.php            Home page
news.php rules.php   Placeholder pages (use the shared layout)
staff.php apply.php
preview.php          Live preview used by the profile editor (logged-in members only)
login.php
includes/
  config.php         Server IP, Bedrock port, Discord link, menu pages, languages
  bootstrap.php      Language detection, translation helper t(), flags, Discord stats
  header.php         <head>, background, navbar, language dropdown
  footer.php         Footer, toast, scripts
lang/                en.php it.php fr.php de.php es.php (all site text)
assets/
  css/style.css      All styles
  js/main.js         Tabs, copy IP, menu, scroll effects
  img/               logo.webp, head.webp, bg.webp, favicon.png
cache/               Discord counts are cached here (must be writable)
```

## Add a new page

1. Copy `news.php` to `yourpage.php` and change `$page` and `$pageTitle`.
2. Add it to `'pages'` in `includes/config.php` to show it in the navbar and footer.
3. Add its title key (for example `nav_yourpage`) to every file in `lang/`.

## Notes

- Language: the dropdown links to `?lang=xx`, which stores a cookie. First visit uses the browser language.
- Discord counts come from the public invite API (cached 5 minutes). If the request fails, the tiles show a dash.
- Placeholder pages show "coming soon" until you replace their content.
- Make sure the `cache/` folder is writable by the web server.

## Accounts & database

- `register.php`, `login.php`, `logout.php` handle sign up / log in / log out.
- Users are saved in `database/aetherbound.sqlite` (SQLite, created automatically on the first sign up). Needs the `pdo_sqlite` PHP extension (enabled in XAMPP).
- Passwords are stored only as `password_hash()` hashes. The `database/` folder is blocked from the web by `.htaccess`: back it up, never share it.
- The `database/` and `cache/` folders must be writable by PHP.
- "Log in with Discord" is a placeholder until a Discord application (Client ID / Secret) is configured.
- Forgot password = open a ticket on Discord (no e-mail reset).

## Profile & admin panel

- After logging in or signing up, members land on `profile.php`: about me, signature, profile photo, change password. `user.php?u=Name` is the public profile other members see.
- `admin.php` (admins only, link in the navbar): **Roles** (create / rename / recolour / delete, shown as a coloured badge) and **Users** (search, assign a role, delete accounts). Admin accounts cannot be deleted from the panel.
- The admin account is created automatically when the database is first built (see `admin_seed` in `includes/config.php`: email `aetherboundadmin@gmail.com`, username `AetherAdmin`). Only the password **hash** is stored. If that email is already registered it is promoted to admin. Change the password from the profile page after the first login.
- Existing databases are upgraded automatically (new columns + `roles` table).
- **Profile picture = face of the member's Minecraft skin**, found from the username (`skin_face_url` in `includes/config.php`, default mc-heads.net; needs the visitor's browser to reach that service, otherwise the default head is shown). Photo upload was removed; old files in `uploads/avatars/` are no longer used.
- **Role type and priority** (Admin → Roles): each role is *Public* (badge only) or *Staff*. Staff roles are listed on `staff.php`, one section per role, sorted by priority (higher number first). Members get a role in Admin → Users.
- **Profile editor**: "About me" has WRITE / PREVIEW and a toolbar (bold, italic, spoiler, link, code, quote, list, centre, H1-H3, colour, divider). Codes: `**bold**` `*italic*` `||spoiler||` `` `code` `` `[text](https://…)` `[color=#ff6aa8]text[/color]` `[center]text[/center]` `# H1` `> quote` `- list` `---`. Text is escaped before formatting (`includes/markdown.php`), so no HTML can be injected. Max length: `about_max` in config (1500).
- The admin panel text and the new editor/staff texts are translated in English and Italian; other languages fall back to English.
- Database schema is now version 2 (roles get `kind` and `priority`): existing databases are upgraded automatically, old roles become *Public*.
